<?php
$con=mysqli_connect("localhost","root","","db_project");
if(!$con)
{
	die("connection failed");
}
?>